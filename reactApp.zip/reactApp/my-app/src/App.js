import React from "react";
import { useEffect, useState } from "react";
import './App.css';

function App() {
  const [items, setItems] = useState([]);
  useEffect(() => {
    fetch("https://api.covid19india.org/state_district_wise.json")
      .then(res => res.json())
      .then(
        (result) => {
          setItems(result);
        },
      )
  }, [])

  const getCountByType = (state, type) => {
    let stateConfirmedCount = 0
    Object.keys(items[state]['districtData']).forEach(district => {
      stateConfirmedCount += items[state]['districtData'][district][type]
    })
    return stateConfirmedCount
  }

  return (
    <div className="App">
      <div className="w-100">
        <header>Coronavirus Outbreak in India</header>
        <div className="p-30">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th className="text-left">State</th>
                <th className="bg-gray" scope="col">Confirmed</th>
                <th className="bg-blue" scope="col">Recovered</th>
                <th className="bg-green" scope="col">Deceased</th>
                <th scope="col">Total</th>

              </tr>
            </thead>
            <tbody>
              {Object.keys(items).map(state => {
                const confirmed = getCountByType(state, 'confirmed')
                const recovered = getCountByType(state, 'recovered')
                const deceased = getCountByType(state, 'deceased')
                return (
                  <tr key={state}>
                    <td className="text-left">{state}</td>
                    <td className="text-gray">{confirmed}</td>
                    <td className="text-blue">{recovered}</td>
                    <td className="text-grn">{deceased}</td>
                    <td>{confirmed+recovered+deceased}</td>
                  </tr>
                  )
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default App;
